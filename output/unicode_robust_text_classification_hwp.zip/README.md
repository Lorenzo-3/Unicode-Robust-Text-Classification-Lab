# Unicode-Robust Text Classification

Lorenzo Marinelli (2043092) — Natural Language Processing, 2025–2026.

This project compares word, character and BPE TF-IDF classifiers with DistilBERT on BANKING77 and TREC. It evaluates Unicode attacks, input defenses, and an optional zero-shot comparison with Jev.

## Read the submission

- [report.pdf](output/pdf/report.pdf): main report.
- [report_alt.pdf](output/pdf/report_alt.pdf): supplied alternate report.
- [Notebooks](notebooks/): experiment code and saved results.
- [Result tables](artifacts/tables/): ten CSV files covering dataset and attack statistics, hyperparameter selection, transformer training, baseline metrics by condition and seed, and Jev comparisons across attack strengths.
- [Dataset metadata](artifacts/datasets/metadata.json) and [recorded environment](artifacts/logs/environment.json): dataset provenance, splits, and the environment used for the saved results.

The reports, saved notebook outputs, and CSV tables can be read without running the experiments. Notebook 02's large debug dump has been removed from this submission copy; its code and other outputs are retained.

## Run the experiments

Requirements: Python 3.12 and `uv`. Extract the ZIP, open a terminal in the directory containing this README, then run:

```bash
uv sync --frozen
uv run --frozen jupyter lab
```

Run notebooks 00–06 in order, with a fresh kernel for each. Their working directory may be the project root or the `notebooks` directory.

| Notebook | Purpose |
| --- | --- |
| [00](notebooks/00_environment_and_smoke_tests.ipynb) | Environment and smoke checks |
| [01](notebooks/01_data_and_eda.ipynb) | Dataset preparation and exploration |
| [02](notebooks/02_unicode_attacks.ipynb) | Unicode attack generation |
| [03](notebooks/03_classical_models.ipynb) | TF-IDF classifier training and evaluation |
| [04](notebooks/04_transformer_models.ipynb) | DistilBERT training and evaluation |
| [05](notebooks/05_defenses.ipynb) | Input defense evaluation |
| [06](notebooks/06_results_and_statistics.ipynb) | Results and statistics |
| [07](notebooks/07_jev_robustness.ipynb) | Optional Jev robustness comparison |

Settings are in [config/experiment.yaml](config/experiment.yaml). [pyproject.toml](pyproject.toml) defines dependencies, and [uv.lock](uv.lock) pins their versions.

Datasets, fitted checkpoints, and prediction caches are omitted. Notebooks 01–05 download the inputs and model weights, train the models, and recreate these artifacts. This requires network access, storage, and training time. Notebook 06 requires predictions from these earlier stages; the included CSV summaries do not replace them.

## Optional Jev evaluation

Notebook 07 also requires the processed inputs and baseline predictions from notebooks 01–04. To replay it without API calls, restore a complete response cache under `artifacts/jev/responses/`. This cache is omitted from the submission.

`RUN_LIVE = False` is the default. Without the required cache, the notebook stops. Requesting missing responses requires explicit opt-in: set `RUN_LIVE = True` and provide `TYPESAFE_API_KEY` through the environment or a local `.env.local` file. Live requests use a paid API. `JEV_OFFLINE=1` disables live requests. Credentials are not included.

## Use of AI tools

ChatGPT and Codex assisted with project design, source checking, notebook development, debugging, statistical checks, and report revision. Jev evaluation uses separate hosted classification calls. The author remains responsible for the experiments, sources, results, and submitted work; the report contains the full disclosure.
